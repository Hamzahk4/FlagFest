import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class FlagQuizGame extends JFrame implements ActionListener {

    private JLabel promptLabel;
    private JButton[] flagButtons;
    private JLabel scoreLabel;
    private int score;
    private int currentRound;
    private final int totalRounds = 240; // safe bet yn
    private ArrayList<FlagQuestion> questions;
    private ArrayList<String> countryCodes;
    private JLabel timerLabel;
    private JButton startButton;
    private Timer gameTimer;
    private int timeRemaining;

    public FlagQuizGame() {
        setTitle("Flag Quiz Game");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Main panel for buttons and prompt thingy
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Panel for flag buttonssssssssss
        JPanel flagPanel = new JPanel();
        flagPanel.setLayout(new GridLayout(2, 2));
        flagPanel.setBackground(Color.BLACK); // Set background color for flag panel

        flagButtons = new JButton[4];
        for (int i = 0; i < 4; i++) {
            flagButtons[i] = new JButton();
            flagButtons[i].setBackground(Color.BLACK);
            flagButtons[i].setOpaque(true);
            flagButtons[i].addActionListener(this);
            flagPanel.add(flagButtons[i]);
        }

        // Panel for score and timer
        JPanel scorePanel = new JPanel();
        scorePanel.setLayout(new GridLayout(1, 2));

        scoreLabel = new JLabel("Score: 0", SwingConstants.CENTER);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 30));
        scoreLabel.setForeground(Color.WHITE);
        scoreLabel.setBackground(Color.BLACK);
        scorePanel.add(scoreLabel);

        timerLabel = new JLabel("Time: 01:00", SwingConstants.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 30));
        timerLabel.setBackground(Color.BLACK);
        timerLabel.setForeground(Color.WHITE);
        scorePanel.add(timerLabel);
        scorePanel.setBackground(Color.BLACK);
        //panel for the top part (start and prompt)
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());

        startButton = new JButton("Start");
        startButton.setFont(new Font("Arial", Font.BOLD, 40));
        startButton.setBackground(Color.GRAY);
        startButton.setForeground(Color.YELLOW);
        startButton.addActionListener(e -> startGame());
        topPanel.add(startButton, BorderLayout.WEST);

        promptLabel = new JLabel("", SwingConstants.CENTER);
        promptLabel.setFont(new Font("Arial", Font.BOLD, 70));
        promptLabel.setBackground(Color.BLACK);
        promptLabel.setOpaque(true);
        promptLabel.setForeground(Color.WHITE);
        topPanel.add(promptLabel, BorderLayout.CENTER);

        mainPanel.add(flagPanel, BorderLayout.CENTER);
        mainPanel.add(scorePanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);

        score = 0;
        currentRound = 0;

        countryCodes = loadCountryCodes();
        questions = loadQuestions();

        askForName();
        // SETTING THE BUTTON AND LABEL LOOK AND POSITIONS
    }
    private void askForName() {
        String name = JOptionPane.showInputDialog(this, "Please enter your name:");

        // RECURSION (if the user never inputs a name, we will recursivley call it again to ask)
        if (name == null || name.isEmpty()) {
            askForName(); // CALL
        } else {
            JOptionPane.showMessageDialog(this, "I've been expecting you " + name + ". This is a flag guessing game. You will have 1 minute to answer questions, and at the end your score will be tabulated. Press 'start' to begin.");
        }
    }


    // making the countryCodes (GPT generated)

    private ArrayList<String> loadCountryCodes() {
        ArrayList<String> codes = new ArrayList<>();
        codes.add("af"); // Afghanistan
        codes.add("al"); // Albania
        codes.add("dz"); // Algeria
        codes.add("ad"); // Andorra
        codes.add("ao"); // Angola
        codes.add("ag"); // Antigua and Barbuda
        codes.add("ar"); // Argentina
        codes.add("am"); // Armenia
        codes.add("au"); // Australia
        codes.add("at"); // Austria
        codes.add("az"); // Azerbaijan
        codes.add("bs"); // Bahamas
        codes.add("bh"); // Bahrain
        codes.add("bd"); // Bangladesh
        codes.add("bb"); // Barbados
        codes.add("by"); // Belarus
        codes.add("be"); // Belgium
        codes.add("bz"); // Belize
        codes.add("bj"); // Benin
        codes.add("bt"); // Bhutan
        codes.add("bo"); // Bolivia
        codes.add("ba"); // Bosnia and Herzegovina
        codes.add("bw"); // Botswana
        codes.add("br"); // Brazil
        codes.add("bn"); // Brunei
        codes.add("bg"); // Bulgaria
        codes.add("bf"); // Burkina Faso
        codes.add("bi"); // Burundi
        codes.add("kh"); // Cambodia
        codes.add("cm"); // Cameroon
        codes.add("ca"); // Canada
        codes.add("cv"); // Cape Verde
        codes.add("cf"); // Central African Republic
        codes.add("td"); // Chad
        codes.add("cl"); // Chile
        codes.add("cn"); // China
        codes.add("co"); // Colombia
        codes.add("km"); // Comoros
        codes.add("cd"); // Democratic Republic of the Congo
        codes.add("cg"); // Republic of the Congo
        codes.add("cr"); // Costa Rica
        codes.add("ci"); // Ivory Coast
        codes.add("hr"); // Croatia
        codes.add("cu"); // Cuba
        codes.add("cy"); // Cyprus
        codes.add("cz"); // Czech Republic
        codes.add("dk"); // Denmark
        codes.add("dj"); // Djibouti
        codes.add("dm"); // Dominica
        codes.add("do"); // Dominican Republic
        codes.add("tl"); // East Timor
        codes.add("ec"); // Ecuador
        codes.add("eg"); // Egypt
        codes.add("sv"); // El Salvador
        codes.add("gq"); // Equatorial Guinea
        codes.add("er"); // Eritrea
        codes.add("ee"); // Estonia
        codes.add("et"); // Ethiopia
        codes.add("fj"); // Fiji
        codes.add("fi"); // Finland
        codes.add("fr"); // France
        codes.add("ga"); // Gabon
        codes.add("gm"); // Gambia
        codes.add("ge"); // Georgia
        codes.add("de"); // Germany
        codes.add("gh"); // Ghana
        codes.add("gr"); // Greece
        codes.add("gd"); // Grenada
        codes.add("gt"); // Guatemala
        codes.add("gn"); // Guinea
        codes.add("gw"); // Guinea-Bissau
        codes.add("gy"); // Guyana
        codes.add("ht"); // Haiti
        codes.add("hn"); // Honduras
        codes.add("hu"); // Hungary
        codes.add("is"); // Iceland
        codes.add("in"); // India
        codes.add("id"); // Indonesia
        codes.add("ir"); // Iran
        codes.add("iq"); // Iraq
        codes.add("ie"); // Ireland
        codes.add("it"); // Italy
        codes.add("jm"); // Jamaica
        codes.add("jp"); // Japan
        codes.add("jo"); // Jordan
        codes.add("kz"); // Kazakhstan
        codes.add("ke"); // Kenya
        codes.add("ki"); // Kiribati
        codes.add("kr"); // South Korea
        codes.add("xk"); // Kosovo
        codes.add("kw"); // Kuwait
        codes.add("kg"); // Kyrgyzstan
        codes.add("la"); // Laos
        codes.add("lv"); // Latvia
        codes.add("lb"); // Lebanon
        codes.add("ls"); // Lesotho
        codes.add("lr"); // Liberia
        codes.add("ly"); // Libya
        codes.add("li"); // Liechtenstein
        codes.add("lt"); // Lithuania
        codes.add("lu"); // Luxembourg
        codes.add("mk"); // Macedonia
        codes.add("mg"); // Madagascar
        codes.add("mw"); // Malawi
        codes.add("my"); // Malaysia
        codes.add("mv"); // Maldives
        codes.add("ml"); // Mali
        codes.add("mt"); // Malta
        codes.add("mh"); // Marshall Islands
        codes.add("mr"); // Mauritania
        codes.add("mu"); // Mauritius
        codes.add("mx"); // Mexico
        codes.add("fm"); // Micronesia
        codes.add("md"); // Moldova
        codes.add("mc"); // Monaco
        codes.add("mn"); // Mongolia
        codes.add("me"); // Montenegro
        codes.add("ma"); // Morocco
        codes.add("mz"); // Mozambique
        codes.add("mm"); // Myanmar
        codes.add("na"); // Namibia
        codes.add("nr"); // Nauru
        codes.add("np"); // Nepal
        codes.add("nl"); // Netherlands
        codes.add("nz"); // New Zealand
        codes.add("ni"); // Nicaragua
        codes.add("ne"); // Niger
        codes.add("ng"); // Nigeria
        codes.add("no"); // Norway
        codes.add("om"); // Oman
        codes.add("pk"); // Pakistan
        codes.add("pw"); // Palau
        codes.add("pa"); // Panama
        codes.add("pg"); // Papua New Guinea
        codes.add("py"); // Paraguay
        codes.add("pe"); // Peru
        codes.add("ph"); // Philippines
        codes.add("pl"); // Poland
        codes.add("pt"); // Portugal
        codes.add("qa"); // Qatar
        codes.add("ro"); // Romania
        codes.add("ru"); // Russia
        codes.add("rw"); // Rwanda
        codes.add("kn"); // Saint Kitts and Nevis
        codes.add("lc"); // Saint Lucia
        codes.add("vc"); // Saint Vincent and the Grenadines
        codes.add("ws"); // Samoa
        codes.add("sm"); // San Marino
        codes.add("st"); // Sao Tome and Principe
        codes.add("sa"); // Saudi Arabia
        codes.add("sn"); // Senegal
        codes.add("rs"); // Serbia
        codes.add("sc"); // Seychelles
        codes.add("sl"); // Sierra Leone
        codes.add("sg"); // Singapore
        codes.add("sk"); // Slovakia
        codes.add("si"); // Slovenia
        codes.add("sb"); // Solomon Islands
        codes.add("so"); // Somalia
        codes.add("za"); // South Africa
        codes.add("ss"); // South Sudan
        codes.add("es"); // Spain
        codes.add("lk"); // Sri Lanka
        codes.add("sd"); // Sudan
        codes.add("sr"); // Suriname
        codes.add("sz"); // Swaziland
        codes.add("se"); // Sweden
        codes.add("ch"); // Switzerland
        codes.add("sy"); // Syria
        codes.add("tw"); // Taiwan
        codes.add("tj"); // Tajikistan
        codes.add("tz"); // Tanzania
        codes.add("th"); // Thailand
        codes.add("tg"); // Togo
        codes.add("to"); // Tonga
        codes.add("tt"); // Trinidad and Tobago
        codes.add("tn"); // Tunisia
        codes.add("tr"); // Turkey
        codes.add("tm"); // Turkmenistan
        codes.add("tv"); // Tuvalu
        codes.add("ug"); // Uganda
        codes.add("ua"); // Ukraine
        codes.add("ae"); // United Arab Emirates
        codes.add("gb"); // United Kingdom
        codes.add("us"); // United States
        codes.add("uy"); // Uruguay
        codes.add("uz"); // Uzbekistan
        codes.add("vu"); // Vanuatu
        codes.add("va"); // Vatican City
        codes.add("ve"); // Venezuela
        codes.add("vn"); // Vietnam
        codes.add("ye"); // Yemen
        codes.add("zm"); // Zambia
        codes.add("zw"); // Zimbabwe
        return codes;
    }


    private ArrayList<FlagQuestion> loadQuestions() {
        ArrayList<FlagQuestion> questions = new ArrayList<>();
        Random rand = new Random();
        List<String> shuffledCountryCodes = new ArrayList<>(countryCodes); //shuffling it so that its random
        Collections.shuffle(shuffledCountryCodes); // Shuffle the country codes

        for (String code : shuffledCountryCodes) {
            List<String> options = new ArrayList<>(countryCodes);
            options.remove(code); // Remove correct answer from options so we know
            List<String> selectedOptions = new ArrayList<>();
            selectedOptions.add(code); // Add correct answer so we can tell whats right

            // 3 other flags at randommm
            for (int i = 0; i < 3; i++) {
                int index = rand.nextInt(options.size());
                selectedOptions.add(options.get(index));
                options.remove(index);
            }

            // this makes it so that the right answer is at a random position
            Collections.shuffle(selectedOptions);

            // finds where it is
            int correctAnswer = selectedOptions.indexOf(code);

            // updated prompt thingamabob
            questions.add(new FlagQuestion("Which flag is of " + getCountryName(code) + "?", selectedOptions, correctAnswer));
        }

        return questions;
    }

    // Timer and startGame GPT generated to handle the timer and stopping the game
    private void updateTimerLabel() {
        int minutes = timeRemaining / 60;
        int seconds = timeRemaining % 60;
        String timeString = String.format("%02d:%02d", minutes, seconds);
        timerLabel.setText("Time: " + timeString);
    }

    private void startGame() {
        startButton.setEnabled(false); // Disable the start button
        timeRemaining = 60; // Set initial time to 60 seconds
        updateTimerLabel(); // Update timer label to display initial time

        // Start the timer
        gameTimer = new Timer(1000, e -> {
            timeRemaining--;
            updateTimerLabel();
            if (timeRemaining <= 0) {
                endGame();
            }
        });
        gameTimer.start();

        // Display the first question
        displayNextQuestion();
    }

    private void endGame() {
        gameTimer.stop();
        startButton.setEnabled(true);

        int totalQuestionsAnswered = currentRound; // how many weve done

        int scorePercentage = (score * 100) / totalQuestionsAnswered;

        JOptionPane.showMessageDialog(this, "Time's up! Your score: " + score + " / " + totalQuestionsAnswered +
                " (" + scorePercentage + "%)", "Game Over", JOptionPane.INFORMATION_MESSAGE);

        score = 0;
        currentRound = 0;
    }

    // GPT GENERATED
    private String getCountryName(String code) {
        if (code.equals("af")) {
            return "Afghanistan";
        } else if (code.equals("al")) {
            return "Albania";
        } else if (code.equals("dz")) {
            return "Algeria";
        } else if (code.equals("ad")) {
            return "Andorra";
        } else if (code.equals("ao")) {
            return "Angola";
        } else if (code.equals("ag")) {
            return "Antigua and Barbuda";
        } else if (code.equals("ar")) {
            return "Argentina";
        } else if (code.equals("am")) {
            return "Armenia";
        } else if (code.equals("au")) {
            return "Australia";
        } else if (code.equals("at")) {
            return "Austria";
        } else if (code.equals("az")) {
            return "Azerbaijan";
        } else if (code.equals("bs")) {
            return "Bahamas";
        } else if (code.equals("bh")) {
            return "Bahrain";
        } else if (code.equals("bd")) {
            return "Bangladesh";
        } else if (code.equals("bb")) {
            return "Barbados";
        } else if (code.equals("by")) {
            return "Belarus";
        } else if (code.equals("be")) {
            return "Belgium";
        } else if (code.equals("bz")) {
            return "Belize";
        } else if (code.equals("bj")) {
            return "Benin";
        } else if (code.equals("bt")) {
            return "Bhutan";
        } else if (code.equals("bo")) {
            return "Bolivia";
        } else if (code.equals("ba")) {
            return "Bosnia and Herzegovina";
        } else if (code.equals("bw")) {
            return "Botswana";
        } else if (code.equals("br")) {
            return "Brazil";
        } else if (code.equals("bn")) {
            return "Brunei";
        } else if (code.equals("bg")) {
            return "Bulgaria";
        } else if (code.equals("bf")) {
            return "Burkina Faso";
        } else if (code.equals("bi")) {
            return "Burundi";
        } else if (code.equals("kh")) {
            return "Cambodia";
        } else if (code.equals("cm")) {
            return "Cameroon";
        } else if (code.equals("ca")) {
            return "Canada";
        } else if (code.equals("cv")) {
            return "Cape Verde";
        } else if (code.equals("cf")) {
            return "Central African Republic";
        } else if (code.equals("td")) {
            return "Chad";
        } else if (code.equals("cl")) {
            return "Chile";
        } else if (code.equals("cn")) {
            return "China";
        } else if (code.equals("co")) {
            return "Colombia";
        } else if (code.equals("km")) {
            return "Comoros";
        } else if (code.equals("cd")) {
            return "Democratic Republic of the Congo";
        } else if (code.equals("cg")) {
            return "Republic of the Congo";
        } else if (code.equals("cr")) {
            return "Costa Rica";
        } else if (code.equals("ci")) {
            return "Ivory Coast";
        } else if (code.equals("hr")) {
            return "Croatia";
        } else if (code.equals("cu")) {
            return "Cuba";
        } else if (code.equals("cy")) {
            return "Cyprus";
        } else if (code.equals("cz")) {
            return "Czech Republic";
        } else if (code.equals("dk")) {
            return "Denmark";
        } else if (code.equals("dj")) {
            return "Djibouti";
        } else if (code.equals("dm")) {
            return "Dominica";
        } else if (code.equals("do")) {
            return "Dominican Republic";
        } else if (code.equals("tl")) {
            return "East Timor";
        } else if (code.equals("ec")) {
            return "Ecuador";
        } else if (code.equals("eg")) {
            return "Egypt";
        } else if (code.equals("sv")) {
            return "El Salvador";
        } else if (code.equals("gq")) {
            return "Equatorial Guinea";
        } else if (code.equals("er")) {
            return "Eritrea";
        } else if (code.equals("ee")) {
            return "Estonia";
        } else if (code.equals("et")) {
            return "Ethiopia";
        } else if (code.equals("fj")) {
            return "Fiji";
        } else if (code.equals("fi")) {
            return "Finland";
        } else if (code.equals("fr")) {
            return "France";
        } else if (code.equals("ga")) {
            return "Gabon";
        } else if (code.equals("gm")) {
            return "Gambia";
        } else if (code.equals("ge")) {
            return "Georgia";
        } else if (code.equals("de")) {
            return "Germany";
        } else if (code.equals("gh")) {
            return "Ghana";
        } else if (code.equals("gr")) {
            return "Greece";
        } else if (code.equals("gd")) {
            return "Grenada";
        } else if (code.equals("gt")) {
            return "Guatemala";
        } else if (code.equals("gn")) {
            return "Guinea";
        } else if (code.equals("gw")) {
            return "Guinea-Bissau";
        } else if (code.equals("gy")) {
            return "Guyana";
        } else if (code.equals("ht")) {
            return "Haiti";
        } else if (code.equals("hn")) {
            return "Honduras";
        } else if (code.equals("hu")) {
            return "Hungary";
        } else if (code.equals("is")) {
            return "Iceland";
        } else if (code.equals("in")) {
            return "India";
        } else if (code.equals("id")) {
            return "Indonesia";
        } else if (code.equals("ir")) {
            return "Iran";
        } else if (code.equals("iq")) {
            return "Iraq";
        } else if (code.equals("ie")) {
            return "Ireland";
        } else if (code.equals("it")) {
            return "Italy";
        } else if (code.equals("jm")) {
            return "Jamaica";
        } else if (code.equals("jp")) {
            return "Japan";
        } else if (code.equals("jo")) {
            return "Jordan";
        } else if (code.equals("kz")) {
            return "Kazakhstan";
        } else if (code.equals("ke")) {
            return "Kenya";
        } else if (code.equals("ki")) {
            return "Kiribati";
        } else if (code.equals("kr")) {
            return "South Korea";
        } else if (code.equals("xk")) {
            return "Kosovo";
        } else if (code.equals("kw")) {
            return "Kuwait";
        } else if (code.equals("kg")) {
            return "Kyrgyzstan";
        } else if (code.equals("la")) {
            return "Laos";
        } else if (code.equals("lv")) {
            return "Latvia";
        } else if (code.equals("lb")) {
            return "Lebanon";
        } else if (code.equals("ls")) {
            return "Lesotho";
        } else if (code.equals("lr")) {
            return "Liberia";
        } else if (code.equals("ly")) {
            return "Libya";
        } else if (code.equals("li")) {
            return "Liechtenstein";
        } else if (code.equals("lt")) {
            return "Lithuania";
        } else if (code.equals("lu")) {
            return "Luxembourg";
        } else if (code.equals("mk")) {
            return "Macedonia";
        } else if (code.equals("mg")) {
            return "Madagascar";
        } else if (code.equals("mw")) {
            return "Malawi";
        } else if (code.equals("my")) {
            return "Malaysia";
        } else if (code.equals("mv")) {
            return "Maldives";
        } else if (code.equals("ml")) {
            return "Mali";
        } else if (code.equals("mt")) {
            return "Malta";
        } else if (code.equals("mh")) {
            return "Marshall Islands";
        } else if (code.equals("mr")) {
            return "Mauritania";
        } else if (code.equals("mu")) {
            return "Mauritius";
        } else if (code.equals("mx")) {
            return "Mexico";
        } else if (code.equals("fm")) {
            return "Micronesia";
        } else if (code.equals("md")) {
            return "Moldova";
        } else if (code.equals("mc")) {
            return "Monaco";
        } else if (code.equals("mn")) {
            return "Mongolia";
        } else if (code.equals("me")) {
            return "Montenegro";
        } else if (code.equals("ma")) {
            return "Morocco";
        } else if (code.equals("mz")) {
            return "Mozambique";
        } else if (code.equals("mm")) {
            return "Myanmar";
        } else if (code.equals("na")) {
            return "Namibia";
        } else if (code.equals("nr")) {
            return "Nauru";
        } else if (code.equals("np")) {
            return "Nepal";
        } else if (code.equals("nl")) {
            return "Netherlands";
        } else if (code.equals("nz")) {
            return "New Zealand";
        } else if (code.equals("ni")) {
            return "Nicaragua";
        } else if (code.equals("ne")) {
            return "Niger";
        } else if (code.equals("ng")) {
            return "Nigeria";
        } else if (code.equals("no")) {
            return "Norway";
        } else if (code.equals("om")) {
            return "Oman";
        } else if (code.equals("pk")) {
            return "Pakistan";
        } else if (code.equals("pw")) {
            return "Palau";
        } else if (code.equals("pa")) {
            return "Panama";
        } else if (code.equals("pg")) {
            return "Papua New Guinea";
        } else if (code.equals("py")) {
            return "Paraguay";
        } else if (code.equals("pe")) {
            return "Peru";
        } else if (code.equals("ph")) {
            return "Philippines";
        } else if (code.equals("pl")) {
            return "Poland";
        } else if (code.equals("pt")) {
            return "Portugal";
        } else if (code.equals("qa")) {
            return "Qatar";
        } else if (code.equals("ro")) {
            return "Romania";
        } else if (code.equals("ru")) {
            return "Russia";
        } else if (code.equals("rw")) {
            return "Rwanda";
        } else if (code.equals("kn")) {
            return "Saint Kitts and Nevis";
        } else if (code.equals("lc")) {
            return "Saint Lucia";
        } else if (code.equals("vc")) {
            return "Saint Vincent and the Grenadines";
        } else if (code.equals("ws")) {
            return "Samoa";
        } else if (code.equals("sm")) {
            return "San Marino";
        } else if (code.equals("st")) {
            return "Sao Tome and Principe";
        } else if (code.equals("sa")) {
            return "Saudi Arabia";
        } else if (code.equals("sn")) {
            return "Senegal";
        } else if (code.equals("rs")) {
            return "Serbia";
        } else if (code.equals("sc")) {
            return "Seychelles";
        } else if (code.equals("sl")) {
            return "Sierra Leone";
        } else if (code.equals("sg")) {
            return "Singapore";
        } else if (code.equals("sk")) {
            return "Slovakia";
        } else if (code.equals("si")) {
            return "Slovenia";
        } else if (code.equals("sb")) {
            return "Solomon Islands";
        } else if (code.equals("so")) {
            return "Somalia";
        } else if (code.equals("za")) {
            return "South Africa";
        } else if (code.equals("ss")) {
            return "South Sudan";
        } else if (code.equals("es")) {
            return "Spain";
        } else if (code.equals("lk")) {
            return "Sri Lanka";
        } else if (code.equals("sd")) {
            return "Sudan";
        } else if (code.equals("sr")) {
            return "Suriname";
        } else if (code.equals("sz")) {
            return "Swaziland";
        } else if (code.equals("se")) {
            return "Sweden";
        } else if (code.equals("ch")) {
            return "Switzerland";
        } else if (code.equals("sy")) {
            return "Syria";
        } else if (code.equals("tw")) {
            return "Taiwan";
        } else if (code.equals("tj")) {
            return "Tajikistan";
        } else if (code.equals("tz")) {
            return "Tanzania";
        } else if (code.equals("th")) {
            return "Thailand";
        } else if (code.equals("tg")) {
            return "Togo";
        } else if (code.equals("to")) {
            return "Tonga";
        } else if (code.equals("tt")) {
            return "Trinidad and Tobago";
        } else if (code.equals("tn")) {
            return "Tunisia";
        } else if (code.equals("tr")) {
            return "Turkey";
        } else if (code.equals("tm")) {
            return "Turkmenistan";
        } else if (code.equals("tv")) {
            return "Tuvalu";
        } else if (code.equals("ug")) {
            return "Uganda";
        } else if (code.equals("ua")) {
            return "Ukraine";
        } else if (code.equals("ae")) {
            return "United Arab Emirates";
        } else if (code.equals("gb")) {
            return "United Kingdom";
        } else if (code.equals("us")) {
            return "United States";
        } else if (code.equals("uy")) {
            return "Uruguay";
        } else if (code.equals("uz")) {
            return "Uzbekistan";
        } else if (code.equals("vu")) {
            return "Vanuatu";
        } else if (code.equals("va")) {
            return "Vatican City";
        } else if (code.equals("ve")) {
            return "Venezuela";
        } else if (code.equals("vn")) {
            return "Vietnam";
        } else if (code.equals("ye")) {
            return "Yemen";
        } else if (code.equals("zm")) {
            return "Zambia";
        } else if (code.equals("zw")) {
            return "Zimbabwe";
        } else {
            return "Unknown";
        }
    }



    private void displayNextQuestion() {
        if (currentRound < totalRounds) {
            if (currentRound < questions.size()) {
                FlagQuestion currentQuestion = questions.get(currentRound);
                promptLabel.setText(currentQuestion.getQuestion());

                for (int i = 0; i < 4; i++) {
                    String imagePath = ".idea/" + currentQuestion.getFlagPaths().get(i) + ".png";
                    ImageIcon icon = new ImageIcon(imagePath);
                    if (icon.getImageLoadStatus() == MediaTracker.ERRORED) {
                        flagButtons[i].setText("Image not found");
                    } else {
                        flagButtons[i].setIcon(icon);
                    }
                    flagButtons[i].setActionCommand(String.valueOf(i));
                }

                currentRound++;

            } else {
                System.err.println("Not enough questions in the list.");
            }
        } else {
            promptLabel.setText("Game Over! Your score: " + score);
            for (JButton flagButton : flagButtons) {
                flagButton.setEnabled(false);
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            int selectedAnswer = Integer.parseInt(e.getActionCommand());
            FlagQuestion currentQuestion = questions.get(currentRound - 1);

            if (selectedAnswer == currentQuestion.getCorrectAnswer()) {
                score++;
            }

            scoreLabel.setText("Score: " + score);
//
//            JOptionPane.showMessageDialog(this, "Correct answer is: " +
//                    getCountryName(currentQuestion.getFlagPaths().get(currentQuestion.getCorrectAnswer())));

            displayNextQuestion();
        } catch (NumberFormatException ex) {

            System.err.println("Error: Action command is not a valid integer");
        }
    }
    // handles the selection of an answer and a catch and try is there cause if you press buttons before pressing start youll get an error


}